#!/usr/bin/env python3

print("""
To generate DISARM please:
cd ../../
git clone https://github.com/DISARMFoundation/DISARMframeworks.git
cd DISARMframeworks/CODE
python3 generate_DISARM_MISP_galaxy.py
""")
